﻿public class ResponseHandler
{
    public static string GetResponse(string input)
    {
        if (input.Contains("how are you"))
            return "I'm doing great! Ready to help you stay safe online.";

        if (input.Contains("purpose"))
            return "My purpose is to educate you about cybersecurity.";

        if (input.Contains("what can i ask"))
            return "You can ask about passwords, phishing, and safe browsing.";

        if (input.Contains("password"))
            return "Use strong passwords with uppercase, numbers, and symbols.";

        if (input.Contains("phishing"))
            return "Avoid suspicious emails asking for personal details.";

        if (input.Contains("safe browsing"))
            return "Only visit secure websites and avoid unknown links.";

        return "I didn’t quite understand that. Could you rephrase?";
    }
}
﻿using System;

public class Chatbot
{
    private string userName;

    public void Start()
    {
        AudioPlayer.PlayGreeting();
        UIHelper.DisplayLogo();

        Console.Write("\nEnter your name: ");
        userName = Console.ReadLine();

        if (string.IsNullOrWhiteSpace(userName))
            userName = "User";

        Console.WriteLine($"\nHello, {userName}! Welcome to the Cybersecurity Awareness Bot.");

        RunChat();
    }

    private void RunChat()
    {
        while (true)
        {
            Console.ForegroundColor = ConsoleColor.Green;
            Console.Write("\nYou: ");
            Console.ResetColor();

            string input = Console.ReadLine().ToLower();

            // Input validation
            if (string.IsNullOrWhiteSpace(input))
            {
                Console.WriteLine("Bot: Please type something.");
                continue;
            }

            string response = ResponseHandler.GetResponse(input);

            Console.ForegroundColor = ConsoleColor.Yellow;
            TypeEffect("Bot: " + response);
            Console.ResetColor();
        }
    }

    private void TypeEffect(string message)
    {
        foreach (char c in message)
        {
            Console.Write(c);
            System.Threading.Thread.Sleep(20);
        }
        Console.WriteLine();
    }
}
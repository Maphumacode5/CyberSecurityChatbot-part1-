﻿using System;

public class UIHelper
{
    public static void DisplayLogo()
    {
        Console.ForegroundColor = ConsoleColor.Cyan;

        Console.WriteLine("=======================================");
        Console.WriteLine("   CYBERSECURITY AWARENESS BOT");
        Console.WriteLine("=======================================");

        Console.WriteLine(@"
        🔒 Protect Your Data
        💻 Stay Safe Online
        🛡️ Fight Cybercrime
        ");

        Console.ResetColor();
    }
}